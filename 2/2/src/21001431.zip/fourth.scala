object fourth {
  def model_1(ticket:Double,attendence:Int):Double = (ticket*attendence)-(500+(3*attendence));
  def model_2(ticket:Double,attendence:Int):Double = (ticket*attendence)-(500+(3*attendence));
  def model_3(ticket:Double,attendence:Int):Double = (ticket*attendence)-(500+(3*attendence));
  def main(args: Array[String]) =  {
    println("Profit of first method = " + model_1(15, 120));
    println("Profit of second method = " + model_2(10, 140));
    println("Profit of thierd method = " + model_3(20, 100));

    println("The best ticket price is= 20");
  }
}


