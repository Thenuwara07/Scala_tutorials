object second {
  def main(args: Array[String]) = {
    var a: Int = 2;
    var b: Int = 3;
    var c: Int = 4;
    var d: Int = 5;
    var k: Float = 4.3f;

    //println(--b * a + c * d--)  Not Supported
    //println(a++)  Not Supported
    //println(-2 * (g-k) + c)  Not declared
    //println(c=c++)  Not Supported
    //println(c=++c*a++)  Not Supported

  }
}
