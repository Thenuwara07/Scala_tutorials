object first {
  def reverse(input: String): String = {
    if (input.isEmpty) ""
    else reverse(input.tail) + input.head
  }

  def main(args: Array[String]): Unit = {
    var str: String = "05jnvfkjxvx"
    println("Reversed String: " + reverse(str))
  }
}
